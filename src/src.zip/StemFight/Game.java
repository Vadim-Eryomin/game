package StemFight;

import Engine.*;

import java.awt.event.KeyEvent;
import java.util.ArrayList;
import java.util.Random;

public class Game extends AbsractGame {
    Game game = this;

    Random random = new Random();
    portalRenderer p = new portalRenderer();

    int secondsSpawn = 0;

    Camera camera = new Camera();
    Hero hero = new Hero();
    Portal portal = new Portal();

    CharFrame charFrame = new CharFrame();
    skillsGraphFrame sgf = new skillsGraphFrame();

    boolean talkWalk = false;
    boolean talkPick = false;
    boolean win = false;
    boolean spawnZombies = true;

    ArrayList<Enemy> enemies = new ArrayList<>();
    ArrayList<AttackParticle> attackParticles = new ArrayList<>();
    ArrayList<BrickParticle> brickParticles = new ArrayList<>();

    GameContainer gc = new GameContainer(this);

    public Game() {
        sgf.create(0,100);
        sgf.setVisible(true);

        charFrame.create(0,0);
        charFrame.setVisible(true);


        portal.create(1000, 1000);
        hero.create(50, 50);
        gc.start();
    }

    @Override
    public void update(GameContainer gc, float dt) {

        charFrame.update(this);
        sgf.update(this);

        hero.update(this);
        portal.update(this);
        camera.update(this);
        for (AttackParticle a : attackParticles) a.update(game);
        for (BrickParticle b : brickParticles)b.update(game);
        for (Enemy e : enemies) e.update(this);
        if (spawnZombies)spawn(this);
        secondsSpawn++;
        for (int i = 0; i < attackParticles.size(); i++) {
            if (attackParticles.get(i).seconds >= 1000) {
                attackParticles.remove(i);
            }
        }

        for (Enemy e : enemies) {
            for (int i = 0; i < attackParticles.size(); i++) {
                if (collision(e, attackParticles.get(i) )) {
                    e.hp -= 35;
                    attackParticles.remove(i);
                }
            }
        }
        for (int i = 0; i < enemies.size(); i++) {
            if (enemies.get(i).hp <= 0) {
                enemies.get(i).death(this);
                enemies.remove(i);
            }
        }
        for (Enemy e : enemies) {
            if (collision(e, hero)) {
                hero.hp -= 5;
                e.hp -= 20;
                new Thread() {
                    @Override
                    public void run() {
                        for (int i = 0; i < 20; i++) {
                            hero.x--;
                            e.x++;
                            try {
                                Thread.sleep(5);
                            } catch (InterruptedException e1) {
                                e1.printStackTrace();
                            }
                        }
                    }
                }.start();
            }
        }
        for (int i = 0; i < brickParticles.size(); i++) {
            if (!brickParticles.get(i).lived){
                brickParticles.remove(i);
            }
        }
    }
    //коллизия работает

    @Override
    public void renderer(GameContainer gc, Renderer renderer) {
        camera.renderer(renderer);
        charFrame.renderer(renderer);
        sgf.renderer(renderer);
        portal.renderer(renderer);
        hero.renderer(renderer);
        for (Enemy e : enemies) e.renderer(renderer);
        for (AttackParticle a : attackParticles) a.renderer(renderer);
        for (BrickParticle b:brickParticles)b.renderer(renderer);
        p.update(this);

    }

    public void spawn(Game game) {
        if (game.secondsSpawn >= 800 && game.enemies.size() < 5) {
            game.secondsSpawn = 0;
            enemies.add(new Enemy());
            enemies.get(enemies.size() - 1).create(random.nextInt(1800), random.nextInt(1800));
        }
    }

    public boolean collision(Enemy A, Hero B) {
        int objAMinX = A.x;
        int objAMaxX = A.x + A.w;
        int objAMinY = A.y;
        int objAMaxY = A.y + A.h;
        int objBMinX = B.x;
        int objBMaxX = B.x + B.w;
        int objBMinY = B.y;
        int objBMaxY = B.y + B.h;

        if (objAMaxX < objBMinX || objAMinX > objBMaxX) return false;
        if (objAMaxY < objBMinY || objAMinY > objBMaxY) return false;
        return true;
    }
    public boolean collision(Enemy A, AttackParticle B) {
        int objAMinX = A.x;
        int objAMaxX = A.x + A.w;
        int objAMinY = A.y;
        int objAMaxY = A.y + A.h;
        int objBMinX = B.x;
        int objBMaxX = B.x + B.w;
        int objBMinY = B.y;
        int objBMaxY = B.y + B.h;

        if (objAMaxX < objBMinX || objAMinX > objBMaxX) return false;
        if (objAMaxY < objBMinY || objAMinY > objBMaxY) return false;
        return true;
    }
    public boolean collision(Enemy A, Bulik B){
        int objAMinX = A.x;
        int objAMaxX = A.x + A.w;
        int objAMinY = A.y;
        int objAMaxY = A.y + A.h;
        int objBMinX = B.x;
        int objBMaxX = B.x + B.w;
        int objBMinY = B.y;
        int objBMaxY = B.y + B.h;

        if (objAMaxX < objBMinX || objAMinX > objBMaxX) return false;
        if (objAMaxY < objBMinY || objAMinY > objBMaxY) return false;
        return true;
    }
    public boolean collision(Hero A, BrickParticle B) {
        int objAMinX = A.x;
        int objAMaxX = A.x + A.w;
        int objAMinY = A.y;
        int objAMaxY = A.y + A.h;
        int objBMinX = B.x;
        int objBMaxX = B.x + B.w;
        int objBMinY = B.y;
        int objBMaxY = B.y + B.h;

        if (objAMaxX < objBMinX || objAMinX > objBMaxX) return false;
        if (objAMaxY < objBMinY || objAMinY > objBMaxY) return false;
        return true;
    }
    public boolean collision(Hero A, Portal B) {
        int objAMinX = A.x;
        int objAMaxX = A.x + A.w;
        int objAMinY = A.y;
        int objAMaxY = A.y + A.h;
        int objBMinX = B.x;
        int objBMaxX = B.x + B.w;
        int objBMinY = B.y;
        int objBMaxY = B.y + B.h;

        if (objAMaxX < objBMinX || objAMinX > objBMaxX) return false;
        if (objAMaxY < objBMinY || objAMinY > objBMaxY) return false;
        return true;
    }

    public static void main(String[] args) {
        new Game();
    }
}
