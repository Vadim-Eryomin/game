package StemFight;

import BossFight.Attack;
import Engine.FramesForGame;
import Engine.ImageXY;
import Engine.Renderer;

import java.awt.event.KeyEvent;

public class SkillsTerminal extends FramesForGame {
    int terminal = 0;

    int x = 0;
    int y = 0;

    ImageXY fon = new ImageXY("../StemFight/Skills/fonTerminal.png", x, y);

    @Override
    public void create(int x, int y) {
        this.x = x;
        this.y = y;

    }

    @Override
    public void update(Game game) {
        terminal = terminal % 3;
        if (game.gc.input.isKeyDown(KeyEvent.VK_Q)){
            terminal++;
        }
    }

    @Override
    public void setVisible(boolean vis) {
        visible = vis;
    }

    @Override
    public void renderer(Renderer renderer) {

    }

    public void createBulk(Game game){
        if(game.hero.right){
            game.attackParticles.add(new Bulik());
        }
    }
}
