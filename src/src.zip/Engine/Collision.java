package Engine;

public class Collision {
}
