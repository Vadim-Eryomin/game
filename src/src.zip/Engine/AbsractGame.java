package Engine;


public abstract class AbsractGame {

    public abstract void update(GameContainer gc, float dt);

    public abstract void renderer(GameContainer gc, Renderer renderer);
}
