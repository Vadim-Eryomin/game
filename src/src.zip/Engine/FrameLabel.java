package Engine;

public class FrameLabel {
    boolean visible = false;
    int x = 0;
    int y = 0;
    String text = "...";

    public FrameLabel(int x, int y, String text){
        if (visible){

        }
    }
    public void setVisible(boolean visible){
        this.visible = visible;
    }
}
